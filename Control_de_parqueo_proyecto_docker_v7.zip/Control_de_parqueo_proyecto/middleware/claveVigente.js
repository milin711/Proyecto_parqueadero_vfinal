const db = require("../db");
const { error } = require("../utils");

// Si la cuenta todavía debe cambiar su contraseña inicial, solo puede usar /auth/password.
module.exports = function claveVigente(req, res, next) {
  const u = db.prepare("SELECT debe_cambiar_clave d FROM usuario WHERE id = ?").get(req.user.id);
  if (!u) return error(res, 401, "La cuenta ya no existe");
  if (u.d) return error(res, 403, "Debes cambiar tu contraseña antes de continuar");
  next();
};
