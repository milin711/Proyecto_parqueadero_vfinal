const db = require("./db");
const { PLENA_DESDE_MIN } = require("./config");

const error = (res, status, mensaje) => res.status(status).json({ error: mensaje });

// Tarifas por minuto vigentes (editables por el ADMIN) -> { CARRO: 150, MOTO: 80, OTRO: 10 }
const getTarifas = () =>
  Object.fromEntries(db.prepare("SELECT tipo, valor_minuto v FROM tarifa").all().map((r) => [r.tipo, r.v]));

const minutosEntre = (desdeISO, hastaISO) =>
  Math.max(1, Math.ceil((new Date(hastaISO) - new Date(desdeISO)) / 60000));

// Tarifa por minuto que aplica a un registro: la que se guardó al entrar (si el admin cambia
// los precios después, los vehículos que ya están dentro no se ven afectados).
const tarifaDe = (r, tarifas = getTarifas()) => r.tarifa_minuto ?? tarifas[r.tipo_vehiculo] ?? tarifas.OTRO;

// Por minuto: cada minuto cuenta y una fracción de minuto se cobra como minuto completo (minutosEntre ya redondea hacia arriba, mínimo 1)
const calcularValor = (minutos, tarifaMinuto, tarifaPlena = null) =>
  tarifaPlena != null && minutos >= PLENA_DESDE_MIN ? tarifaPlena : Math.ceil(minutos) * tarifaMinuto;

// Tarifa plena de cada tipo (valor fijo que se cobra desde PLENA_DESDE_MIN minutos)
const getPlenas = () =>
  Object.fromEntries(db.prepare("SELECT tipo, valor_plena v FROM tarifa").all().map((r) => [r.tipo, r.v]));
// La que se guardó al entrar (si el admin cambia los precios después, el vehículo que ya está dentro no se ve afectado)
const plenaDe = (r, plenas = getPlenas()) => r.tarifa_plena ?? plenas[r.tipo_vehiculo] ?? plenas.OTRO;

// Cobro completo de un registro abierto con `min` minutos dentro
const detalleCobro = (r, min, tarifas = getTarifas(), plenas = getPlenas()) => {
  const tarifaMinuto = tarifaDe(r, tarifas), tarifaPlena = plenaDe(r, plenas), plenaAplicada = min >= PLENA_DESDE_MIN;
  return { tarifaMinuto, tarifaPlena, plenaDesdeMin: PLENA_DESDE_MIN, plenaAplicada,
           faltanParaPlenaMin: plenaAplicada ? 0 : PLENA_DESDE_MIN - min, valorEstimado: calcularValor(min, tarifaMinuto, tarifaPlena) };
};

const normalizarPlaca = (p) => String(p || "").trim().toUpperCase();

module.exports = { error, getTarifas, getPlenas, tarifaDe, plenaDe, detalleCobro, minutosEntre, calcularValor, normalizarPlaca, PLENA_DESDE_MIN };
