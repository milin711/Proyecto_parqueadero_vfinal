const db = require("./db");

// Personalización de las sugerencias a partir del historial del PROPIO usuario.
// Solo se usan sus estancias y sus calificaciones. Es determinista y explicable: cada ajuste trae su razón.
// (El asistente de chat NO usa este módulo: las sugerencias de cupo viven solo aquí y en sugerencias.js.)

const r1 = (x) => Math.round(x * 10) / 10;

// Devuelve null si la persona aún no tiene salidas registradas.
function perfilDe(userId) {
  const filas = db.prepare(`
    SELECT r.cupo_id, c.piso, k.luminosidad kl, k.posicion kp, k.seguridad ks
    FROM registro r JOIN cupo c ON c.id = r.cupo_id
    LEFT JOIN calificacion k ON k.registro_id = r.id
    WHERE r.usuario_id = ? AND r.estado = 'FINALIZADO'`).all(userId);
  if (!filas.length) return null;

  const porCupo = new Map(), porPiso = new Map();
  for (const f of filas) {
    const c = porCupo.get(f.cupo_id) || { veces: 0, suma: 0, nCal: 0 };
    c.veces++;
    if (f.kl != null) { c.suma += f.kl + f.kp + f.ks; c.nCal++; }
    porCupo.set(f.cupo_id, c);
    porPiso.set(f.piso, (porPiso.get(f.piso) || 0) + 1);
  }
  // Zona habitual: el piso donde estaciona al menos la mitad de las veces (y mínimo 2 veces)
  const [piso, veces] = [...porPiso.entries()].sort((a, b) => b[1] - a[1])[0];
  return { estancias: filas.length, porCupo, pisoHabitual: veces >= 2 && veces / filas.length >= 0.5 ? piso : null };
}

// Ajuste para un cupo candidato: sube (+) los que le gustaron o usa seguido y baja (-) los que calificó mal.
function afinidadDe(perfil, c) {
  const p = perfil.porCupo.get(c.cupoId);
  const mi = p && p.nCal ? p.suma / (p.nCal * 3) : null; // promedio de estrellas que ÉL dio a ese cupo
  const razones = [];
  let bonus = 0;
  if (p) {
    if (mi !== null && mi <= 2.5) { bonus -= 2; razones.push(`Lo calificaste bajo (${r1(mi)}★)`); }
    else {
      razones.push(p.veces === 1 ? "Ya parqueaste aquí una vez" : `Ya parqueaste aquí ${p.veces} veces`);
      if (p.veces >= 2) bonus += 0.3;
      if (mi !== null && mi >= 4) { bonus += 0.8; razones.push(`Lo calificaste con ${r1(mi)}★`); }
    }
  }
  if (perfil.pisoHabitual === c.piso) { bonus += 0.2; razones.push(`Está en tu zona habitual (piso ${c.piso})`); }
  bonus = Math.max(-2, Math.min(1, bonus));
  return { bonus, razones, veces: p?.veces || 0, miCalificacion: mi !== null ? r1(mi) : null, zonaHabitual: perfil.pisoHabitual === c.piso };
}

module.exports = { perfilDe, afinidadDe };
