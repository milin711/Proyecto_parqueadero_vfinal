const fs = require("fs");
const path = require("path");

// Lee un archivo .env (si existe) para no tener que escribir variables en la terminal.
// Formato:  CLAVE=valor   (líneas que empiezan con # son comentarios)
try {
  for (const l of fs.readFileSync(path.join(__dirname, ".env"), "utf8").split(/\r?\n/)) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !l.trim().startsWith("#") && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
} catch { /* sin .env: se usan los valores por defecto */ }

module.exports = {
  PORT: process.env.PORT || 3000,
  // Dónde se guarda la base de datos. En Docker apunta a un volumen (/data) para no perder datos.
  DB_PATH: process.env.DB_PATH || path.join(__dirname, "parqueadero.db"),
  SECRET: process.env.JWT_SECRET || "cambia-esta-clave",
  EXPIRA_SEG: 8 * 60 * 60,

  // Valores permitidos (la base de datos también los valida con CHECK)
  ROLES: ["ADMIN", "OPERADOR", "CLIENTE"],
  TIPOS_VEHICULO: ["CARRO", "MOTO", "OTRO"],
  METODOS_PAGO: ["EFECTIVO", "TARJETA", "TRANSFERENCIA"],

  // Respaldos automáticos de la base de datos (uno cada 24 h; se conservan los últimos BACKUP_KEEP)
  BACKUP_DIR: process.env.BACKUP_DIR || path.join(__dirname, "respaldos"),
  BACKUP_KEEP: Number(process.env.BACKUP_KEEP || 14),
  // Asistente de IA para sugerir cupos. La clave SOLO vive en el servidor (archivo .env); sin clave,
  // las sugerencias se calculan igual con las calificaciones, solo que sin la explicación de la IA.
  // Proveedor: "gemini" (Google AI Studio, por defecto) o "anthropic" (Claude).
  IA: (() => {
    const proveedor = (process.env.IA_PROVEEDOR || "gemini").toLowerCase() === "anthropic" ? "anthropic" : "gemini";
    const def = proveedor === "gemini"
      ? { modelo: "gemini-3.5-flash-lite", baseUrl: "https://generativelanguage.googleapis.com", nombre: "Google Gemini" }
      : { modelo: "claude-haiku-5-5", baseUrl: "https://api.anthropic.com", nombre: "Anthropic Claude" };
    return {
      proveedor, nombre: def.nombre,
      apiKey: process.env.IA_API_KEY || process.env.GEMINI_API_KEY || "",
      modelo: process.env.IA_MODELO || def.modelo,
      baseUrl: (process.env.IA_BASE_URL || def.baseUrl).replace(/\/+$/, ""),
      timeoutMs: Number(process.env.IA_TIMEOUT_MS || 15000),
      maxPorHora: Number(process.env.IA_MAX_POR_HORA || 30), // consultas a la IA por usuario y por hora (control de costo)
      maxChatPorHora: Number(process.env.IA_CHAT_MAX_POR_HORA || 20), // mensajes al asistente por usuario y hora (tope aparte del de sugerencias)
    };
  })(),
  DIAS_PARA_CALIFICAR: 14, // plazo para calificar un cupo después de la salida
  // Tarifa inicial POR MINUTO en pesos (COP): carro 150, moto 80, otro (bicicleta) 10. Luego el ADMIN las edita desde la app.
  // Cada minuto cuenta y una fracción de minuto se cobra como minuto completo (mínimo 1 minuto).
  TARIFA_MINUTO: { CARRO: 150, MOTO: 80, OTRO: 10 },
  // Tarifa plena: desde este tiempo (por defecto 3 horas = 180 minutos) se cobra un valor fijo por tipo de vehículo
  // en lugar de contar minutos. El ADMIN edita ese valor por tipo; la migración lo inicia en (minutos x tarifa por minuto).
  PLENA_DESDE_MIN: Number.isInteger(Number(process.env.TARIFA_PLENA_MINUTOS)) && Number(process.env.TARIFA_PLENA_MINUTOS) >= 1 ? Number(process.env.TARIFA_PLENA_MINUTOS) : 180,

  // Correo saliente (recuperación de contraseña). Si SMTP_HOST/SMTP_USER están vacíos,
  // el código se muestra en la consola del servidor en lugar de enviarse (modo pruebas).
  SMTP: {
    host: process.env.SMTP_HOST || "",
    port: Number(process.env.SMTP_PORT || 587),
    user: process.env.SMTP_USER || "",
    pass: process.env.SMTP_PASS || "",
    from: process.env.SMTP_FROM || (process.env.SMTP_USER ? `ParkControl <${process.env.SMTP_USER}>` : "ParkControl"),
  },
  CODIGO_MINUTOS: 15, // vigencia del código de recuperación
};
