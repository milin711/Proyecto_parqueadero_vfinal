const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const { TARIFA_MINUTO, PLENA_DESDE_MIN, DB_PATH, ROLES, TIPOS_VEHICULO, METODOS_PAGO } = require("./config");
// Tarifas iniciales POR HORA que usaban las migraciones v1 y v2 (el cobro era por hora). La v4 las convierte a cobro por minuto.
const TARIFA_HORA_V1 = { CARRO: 2000, MOTO: 1000, OTRO: 500 };

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");   // lecturas y escrituras no se bloquean entre sí; más seguro ante cortes
db.pragma("synchronous = NORMAL"); // seguro con WAL y más rápido
db.pragma("busy_timeout = 5000");  // si la base está ocupada, espera hasta 5 s en vez de fallar
db.pragma("foreign_keys = ON");

const lista = (a) => a.map((x) => `'${x}'`).join(",");
const SQL_ROLES = lista(ROLES), SQL_TIPOS = lista(TIPOS_VEHICULO), SQL_PAGOS = lista(METODOS_PAGO);

// ---------- Distribución de cupos: 100 en total ----------
// CR 01..CR 50 (carro) · MT 01..MT 35 (moto) · OT 01..OT 15 (otro)
const DISTRIBUCION = [
  { tipo: "CARRO", prefijo: "CR", total: 50 },
  { tipo: "MOTO", prefijo: "MT", total: 35 },
  { tipo: "OTRO", prefijo: "OT", total: 15 },
];
const codigoCupo = (prefijo, n) => `${prefijo} ${String(n).padStart(2, "0")}`;

// =====================================================================================
//  MIGRACIONES NUMERADAS
//  El número de versión se guarda en la propia base (PRAGMA user_version). Al arrancar se
//  ejecutan, en orden, solo las que faltan; cada una dentro de una transacción (si algo
//  falla se deshace entera). Para cambiar el esquema en el futuro: agrega una migración
//  nueva al final de la lista y NO edites las anteriores.
// =====================================================================================

// v1 — Esquema original (se conserva tal cual para poder actualizar bases creadas antes).
function migracion1() {
  db.exec(`
CREATE TABLE IF NOT EXISTS usuario (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  usuario TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  rol TEXT NOT NULL DEFAULT 'OPERADOR'
);
CREATE TABLE IF NOT EXISTS parqueadero (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  direccion TEXT,
  capacidad_total INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS cupo (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parqueadero_id INTEGER NOT NULL REFERENCES parqueadero(id),
  codigo TEXT NOT NULL,
  piso INTEGER NOT NULL DEFAULT 1,
  tipo TEXT NOT NULL DEFAULT 'CARRO',
  estado TEXT NOT NULL DEFAULT 'LIBRE' CHECK (estado IN ('LIBRE','OCUPADO','MANTENIMIENTO')),
  UNIQUE (parqueadero_id, codigo)
);
CREATE TABLE IF NOT EXISTS registro (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cupo_id INTEGER NOT NULL REFERENCES cupo(id),
  placa TEXT NOT NULL,
  tipo_vehiculo TEXT NOT NULL,
  hora_entrada TEXT NOT NULL,
  hora_salida TEXT,
  valor_total INTEGER,
  metodo_pago TEXT,
  estado TEXT NOT NULL DEFAULT 'EN_CURSO' CHECK (estado IN ('EN_CURSO','FINALIZADO'))
);
`);
  if (!db.prepare("PRAGMA table_info(registro)").all().some((c) => c.name === "usuario_id"))
    db.exec("ALTER TABLE registro ADD COLUMN usuario_id INTEGER REFERENCES usuario(id)");
  if (!db.prepare("PRAGMA table_info(usuario)").all().some((c) => c.name === "email"))
    db.exec("ALTER TABLE usuario ADD COLUMN email TEXT");
  db.exec("CREATE UNIQUE INDEX IF NOT EXISTS ux_usuario_email ON usuario(email COLLATE NOCASE) WHERE email IS NOT NULL");
  db.exec(`CREATE TABLE IF NOT EXISTS recuperacion (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    usuario_id INTEGER NOT NULL REFERENCES usuario(id),
    codigo_hash TEXT NOT NULL,
    expira_en TEXT NOT NULL,
    intentos INTEGER NOT NULL DEFAULT 0,
    creado_en TEXT NOT NULL
  )`);
  db.exec("CREATE TABLE IF NOT EXISTS tarifa (tipo TEXT PRIMARY KEY, valor_hora INTEGER NOT NULL)");
  if (db.prepare("SELECT COUNT(*) c FROM tarifa").get().c === 0) {
    const t = db.prepare("INSERT INTO tarifa (tipo, valor_hora) VALUES (?,?)");
    for (const [tipo, v] of Object.entries(TARIFA_HORA_V1)) t.run(tipo, v);
  }

  // Convierte una base ya existente (cupos A1, B1, M1...) a la distribución de 100 cupos,
  // conservando el historial: los cupos viejos se renombran, no se borran.
  if (db.prepare("SELECT COUNT(*) c FROM cupo").get().c > 0) {
    db.exec("UPDATE cupo SET codigo = '#' || id"); // evita choques de UNIQUE al renombrar
    const upd = db.prepare("UPDATE cupo SET codigo = ?, tipo = ? WHERE id = ?");
    const ins = db.prepare("INSERT INTO cupo (parqueadero_id, codigo, piso, tipo) VALUES (?,?,1,?)");
    const pid = db.prepare("SELECT id FROM parqueadero ORDER BY id LIMIT 1").get()?.id ?? 1;
    for (const { tipo, prefijo, total } of DISTRIBUCION) {
      const viejos = db.prepare("SELECT id FROM cupo WHERE tipo = ? ORDER BY id").all(tipo);
      viejos.forEach((c, i) => upd.run(codigoCupo(prefijo, i + 1), tipo, c.id));
      for (let n = viejos.length + 1; n <= total; n++) ins.run(pid, codigoCupo(prefijo, n), tipo);
    }
    db.exec("UPDATE parqueadero SET capacidad_total = (SELECT COUNT(*) FROM cupo)");
  }
}

// v2 — Integridad y rendimiento:
//   · restricciones CHECK (rol, tipo de cupo, tipo de vehículo, método de pago, valores no negativos)
//   · tarifa_hora guardada en cada registro (el cobro no cambia si el admin edita la tarifa)
//   · se elimina parqueadero.capacidad_total (se calcula contando los cupos)
//   · usuario.debe_cambiar_clave (obliga a cambiar la clave inicial del admin)
//   · índices de búsqueda e índices únicos que impiden dos registros abiertos para la misma placa o cupo
function migracion2() {
  // Los datos fuera de lo permitido se corrigen al copiarlos (nada se borra).
  db.exec(`
CREATE TABLE tarifa_n (
  tipo TEXT PRIMARY KEY CHECK (tipo IN (${SQL_TIPOS})),
  valor_hora INTEGER NOT NULL CHECK (valor_hora >= 0)
);
INSERT INTO tarifa_n SELECT tipo, MAX(valor_hora, 0) FROM tarifa WHERE tipo IN (${SQL_TIPOS});
DROP TABLE tarifa;
ALTER TABLE tarifa_n RENAME TO tarifa;

CREATE TABLE usuario_n (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  usuario TEXT UNIQUE NOT NULL,
  email TEXT,
  password_hash TEXT NOT NULL,
  rol TEXT NOT NULL DEFAULT 'CLIENTE' CHECK (rol IN (${SQL_ROLES})),
  debe_cambiar_clave INTEGER NOT NULL DEFAULT 0 CHECK (debe_cambiar_clave IN (0,1))
);
INSERT INTO usuario_n (id, nombre, usuario, email, password_hash, rol)
  SELECT id, nombre, usuario, email, password_hash,
         CASE WHEN rol IN (${SQL_ROLES}) THEN rol ELSE 'CLIENTE' END
  FROM usuario;
DROP TABLE usuario;
ALTER TABLE usuario_n RENAME TO usuario;
CREATE UNIQUE INDEX ux_usuario_email ON usuario(email COLLATE NOCASE) WHERE email IS NOT NULL;

ALTER TABLE parqueadero DROP COLUMN capacidad_total;

CREATE TABLE cupo_n (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parqueadero_id INTEGER NOT NULL REFERENCES parqueadero(id),
  codigo TEXT NOT NULL,
  piso INTEGER NOT NULL DEFAULT 1 CHECK (piso BETWEEN 1 AND 20),
  tipo TEXT NOT NULL DEFAULT 'CARRO' CHECK (tipo IN (${SQL_TIPOS})),
  estado TEXT NOT NULL DEFAULT 'LIBRE' CHECK (estado IN ('LIBRE','OCUPADO','MANTENIMIENTO')),
  UNIQUE (parqueadero_id, codigo)
);
INSERT INTO cupo_n (id, parqueadero_id, codigo, piso, tipo, estado)
  SELECT id, parqueadero_id, codigo, MIN(MAX(piso, 1), 20),
         CASE WHEN tipo IN (${SQL_TIPOS}) THEN tipo ELSE 'OTRO' END, estado
  FROM cupo;
DROP TABLE cupo;
ALTER TABLE cupo_n RENAME TO cupo;

CREATE TABLE registro_n (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  cupo_id INTEGER NOT NULL REFERENCES cupo(id),
  usuario_id INTEGER REFERENCES usuario(id),
  placa TEXT NOT NULL,
  tipo_vehiculo TEXT NOT NULL CHECK (tipo_vehiculo IN (${SQL_TIPOS})),
  hora_entrada TEXT NOT NULL,
  hora_salida TEXT,
  tarifa_hora INTEGER CHECK (tarifa_hora IS NULL OR tarifa_hora >= 0),
  valor_total INTEGER CHECK (valor_total IS NULL OR valor_total >= 0),
  metodo_pago TEXT CHECK (metodo_pago IS NULL OR metodo_pago IN (${SQL_PAGOS})),
  estado TEXT NOT NULL DEFAULT 'EN_CURSO' CHECK (estado IN ('EN_CURSO','FINALIZADO'))
);
INSERT INTO registro_n (id, cupo_id, usuario_id, placa, tipo_vehiculo, hora_entrada, hora_salida,
                        tarifa_hora, valor_total, metodo_pago, estado)
  SELECT r.id, r.cupo_id, r.usuario_id, r.placa,
         CASE WHEN r.tipo_vehiculo IN (${SQL_TIPOS}) THEN r.tipo_vehiculo ELSE 'OTRO' END,
         r.hora_entrada, r.hora_salida,
         CASE WHEN r.estado = 'EN_CURSO'
              THEN (SELECT t.valor_hora FROM tarifa t WHERE t.tipo = r.tipo_vehiculo) END,
         CASE WHEN r.valor_total >= 0 THEN r.valor_total END,
         CASE WHEN r.metodo_pago IN (${SQL_PAGOS}) THEN r.metodo_pago END,
         r.estado
  FROM registro r;
DROP TABLE registro;
ALTER TABLE registro_n RENAME TO registro;

CREATE INDEX ix_registro_placa ON registro(placa);
CREATE INDEX ix_registro_estado ON registro(estado);
CREATE INDEX ix_registro_entrada ON registro(hora_entrada);
CREATE INDEX ix_registro_cupo ON registro(cupo_id);
CREATE INDEX ix_registro_usuario ON registro(usuario_id, estado);
CREATE INDEX ix_cupo_estado ON cupo(parqueadero_id, estado);
CREATE INDEX ix_recuperacion_usuario ON recuperacion(usuario_id);
CREATE INDEX ix_recuperacion_expira ON recuperacion(expira_en);
`);

  // Faltaba alguna tarifa? Se completa con el valor inicial.
  const t = db.prepare("INSERT OR IGNORE INTO tarifa (tipo, valor_hora) VALUES (?,?)");
  for (const [tipo, v] of Object.entries(TARIFA_HORA_V1)) t.run(tipo, v);

  // Una placa o un cupo no pueden tener dos registros abiertos a la vez.
  try {
    db.exec(`
CREATE UNIQUE INDEX ux_registro_cupo_activo ON registro(cupo_id) WHERE estado = 'EN_CURSO';
CREATE UNIQUE INDEX ux_registro_placa_activa ON registro(placa) WHERE estado = 'EN_CURSO';`);
  } catch (e) {
    throw new Error("Hay registros abiertos duplicados (misma placa o mismo cupo). Ciérralos y reinicia. Detalle: " + e.message);
  }

  // Administradores que todavía usan la clave inicial deben cambiarla al entrar.
  for (const a of db.prepare("SELECT id, password_hash FROM usuario WHERE rol = 'ADMIN'").all())
    if (bcrypt.compareSync("admin123", a.password_hash))
      db.prepare("UPDATE usuario SET debe_cambiar_clave = 1 WHERE id = ?").run(a.id);

  const rotos = db.pragma("foreign_key_check");
  if (rotos.length) throw new Error("La migración dejó referencias rotas: " + JSON.stringify(rotos.slice(0, 3)));
}

// v3 — Calificaciones de cupos (alimentan las sugerencias con IA):
//   el usuario califica de 1 a 5 la luminosidad, la posición y la seguridad del cupo donde parqueó,
//   una sola vez por salida. "oculto" permite al administrador retirar una calificación indebida.
function migracion3() {
  db.exec(`
CREATE TABLE calificacion (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  registro_id INTEGER NOT NULL UNIQUE REFERENCES registro(id),
  cupo_id INTEGER NOT NULL REFERENCES cupo(id),
  usuario_id INTEGER NOT NULL REFERENCES usuario(id),
  luminosidad INTEGER NOT NULL CHECK (luminosidad BETWEEN 1 AND 5),
  posicion INTEGER NOT NULL CHECK (posicion BETWEEN 1 AND 5),
  seguridad INTEGER NOT NULL CHECK (seguridad BETWEEN 1 AND 5),
  comentario TEXT CHECK (comentario IS NULL OR length(comentario) <= 200),
  oculto INTEGER NOT NULL DEFAULT 0 CHECK (oculto IN (0,1)),
  creado_en TEXT NOT NULL
);
CREATE INDEX ix_calificacion_cupo ON calificacion(cupo_id, oculto);
CREATE INDEX ix_calificacion_usuario ON calificacion(usuario_id);`);
}

// v4 — Cobro por minuto (antes era por hora o fracción):
//   · tarifa.valor_hora pasa a tarifa.valor_minuto y registro.tarifa_hora a registro.tarifa_minuto
//   · las tarifas quedan en las iniciales por minuto (carro 150, moto 80, otro/bicicleta 10); el ADMIN puede editarlas
//   · los vehículos que están dentro en este momento pasan a cobrarse por minuto con la tarifa nueva de su tipo
//   · las salidas ya cobradas conservan su valor_total; su tarifa por hora ya no tiene equivalente y se deja vacía
function migracion4() {
  db.exec(`
ALTER TABLE tarifa RENAME COLUMN valor_hora TO valor_minuto;
ALTER TABLE registro RENAME COLUMN tarifa_hora TO tarifa_minuto;`);
  const poner = db.prepare("UPDATE tarifa SET valor_minuto = ? WHERE tipo = ?");
  for (const [tipo, v] of Object.entries(TARIFA_MINUTO)) poner.run(v, tipo);
  db.exec(`
UPDATE registro SET tarifa_minuto = (SELECT t.valor_minuto FROM tarifa t WHERE t.tipo = registro.tipo_vehiculo) WHERE estado = 'EN_CURSO';
UPDATE registro SET tarifa_minuto = NULL WHERE estado = 'FINALIZADO';`);
}

// v5 — Tarifa plena: desde PLENA_DESDE_MIN minutos (3 horas) se cobra un valor fijo por tipo de vehículo.
//   · tarifa.valor_plena (editable por el ADMIN) y registro.tarifa_plena (se guarda al entrar, como la tarifa por minuto)
//   · valor inicial = PLENA_DESDE_MIN x tarifa por minuto, así el precio no da saltos al llegar a las 3 horas
//   · los vehículos que ya están dentro reciben la tarifa plena de su tipo
function migracion5() {
  db.exec(`
ALTER TABLE tarifa ADD COLUMN valor_plena INTEGER NOT NULL DEFAULT 0 CHECK (valor_plena >= 0);
ALTER TABLE registro ADD COLUMN tarifa_plena INTEGER CHECK (tarifa_plena IS NULL OR tarifa_plena >= 0);`);
  db.prepare("UPDATE tarifa SET valor_plena = valor_minuto * ?").run(PLENA_DESDE_MIN);
  db.exec("UPDATE registro SET tarifa_plena = (SELECT t.valor_plena FROM tarifa t WHERE t.tipo = registro.tipo_vehiculo) WHERE estado = 'EN_CURSO'");
}

const MIGRACIONES = [[1, migracion1], [2, migracion2], [3, migracion3], [4, migracion4], [5, migracion5]];
const ULTIMA = MIGRACIONES[MIGRACIONES.length - 1][0];

const versionActual = db.pragma("user_version", { simple: true });
const pendientes = MIGRACIONES.filter(([v]) => v > versionActual);
if (pendientes.length) {
  const yaTeniaDatos = !!db.prepare("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'usuario'").get();
  if (yaTeniaDatos) {
    // Copia de seguridad antes de tocar una base existente
    const copia = `${DB_PATH}.antes-v${ULTIMA}.bak`;
    try { fs.rmSync(copia, { force: true }); db.prepare("VACUUM INTO ?").run(copia); console.log("Copia previa a la migración:", copia); }
    catch (e) { console.warn("AVISO: no se pudo crear la copia previa a la migración:", e.message); }
  }
  db.pragma("foreign_keys = OFF"); // necesario para reconstruir tablas; se vuelve a activar abajo
  try {
    for (const [v, fn] of pendientes) {
      db.transaction(() => { fn(); db.pragma(`user_version = ${v}`); })();
      console.log(`Base de datos actualizada a la versión ${v}`);
    }
  } finally {
    db.pragma("foreign_keys = ON");
  }
}

// ---------- Datos iniciales (solo la primera vez) ----------
if (db.prepare("SELECT COUNT(*) c FROM usuario").get().c === 0) {
  db.prepare("INSERT INTO usuario (nombre, usuario, password_hash, rol, debe_cambiar_clave) VALUES (?,?,?,?,1)")
    .run("Administrador", "admin", bcrypt.hashSync("admin123", 10), "ADMIN");
  db.prepare("INSERT INTO parqueadero (nombre, direccion) VALUES (?,?)").run("Parqueadero Central", "Calle 10 # 5-20");
  const ins = db.prepare("INSERT INTO cupo (parqueadero_id, codigo, piso, tipo) VALUES (1,?,1,?)");
  db.transaction(() => {
    for (const { tipo, prefijo, total } of DISTRIBUCION)
      for (let n = 1; n <= total; n++) ins.run(codigoCupo(prefijo, n), tipo);
  })();
  console.log("Datos iniciales creados. Usuario: admin / Contraseña inicial: admin123 (se te pedirá cambiarla al entrar)");
}

module.exports = db;
