// Crea un respaldo ahora mismo:   npm run respaldo
// En Docker:                      docker compose exec parkcontrol node respaldo.js
const { respaldar } = require("./mantenimiento");
respaldar().then((f) => { console.log("Respaldo creado:", f); process.exit(0); })
  .catch((e) => { console.error("Error:", e.message); process.exit(1); });
