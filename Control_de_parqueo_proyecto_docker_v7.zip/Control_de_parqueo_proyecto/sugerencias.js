const db = require("./db");
const { afinidadDe } = require("./perfil");

// Cálculo de las sugerencias de cupo a partir de las calificaciones de los usuarios.
// Los puntajes los calcula el SISTEMA (así son reproducibles); la IA solo elige y explica.

const MEDIDAS = ["luminosidad", "posicion", "seguridad"];
const PRIORIDADES = ["mejor", ...MEDIDAS];
const NOMBRE = { luminosidad: "iluminación", posicion: "ubicación", seguridad: "seguridad" };
const K = 3;           // "peso" de la nota previa: con pocas opiniones el puntaje se acerca al promedio general
const PRIOR = 3.5;     // nota (1 a 5) que se usa mientras casi no hay calificaciones en todo el parqueadero
const MIN_GLOBAL = 5;  // calificaciones mínimas para confiar en el promedio general

const r1 = (x) => Math.round(x * 10) / 10;
const esDeNoche = (d = new Date()) => d.getHours() >= 18 || d.getHours() < 6;

// Importancia de cada medida. Si la persona elige una prioridad, esa pesa el 50 %.
function pesosPara(prioridad, noche) {
  if (MEDIDAS.includes(prioridad)) return Object.fromEntries(MEDIDAS.map((m) => [m, m === prioridad ? 0.5 : 0.25]));
  return noche ? { luminosidad: 0.4, posicion: 0.2, seguridad: 0.4 } : { luminosidad: 0.3, posicion: 0.3, seguridad: 0.4 };
}

function promediosGlobales() {
  const g = db.prepare(`SELECT COUNT(*) n, AVG(luminosidad) l, AVG(posicion) p, AVG(seguridad) s FROM calificacion WHERE oculto = 0`).get();
  return g.n >= MIN_GLOBAL ? { luminosidad: g.l, posicion: g.p, seguridad: g.s } : { luminosidad: PRIOR, posicion: PRIOR, seguridad: PRIOR };
}

// Cupos libres del tipo pedido, ordenados de mejor a peor.
function ranking({ tipoVehiculo, prioridad = "mejor", parqueaderoId = 1, ahora = new Date(), perfil = null }) {
  const noche = esDeNoche(ahora);
  const pesos = pesosPara(prioridad, noche);
  const glob = promediosGlobales();

  const filas = db.prepare(`
    SELECT c.id, c.codigo, c.piso, c.tipo, COUNT(k.id) n,
           AVG(k.luminosidad) l, AVG(k.posicion) p, AVG(k.seguridad) s
    FROM cupo c LEFT JOIN calificacion k ON k.cupo_id = c.id AND k.oculto = 0
    WHERE c.parqueadero_id = ? AND c.estado = 'LIBRE' AND c.tipo = ?
    GROUP BY c.id`).all(parqueaderoId, tipoVehiculo);

  // Puntaje 0-10 = promedio de estrellas (1-5) suavizado con el promedio general, por 2
  const suave = (n, prom, g) => ((n * (prom ?? 0) + K * g) / (n + K)) * 2;
  const candidatos = filas.map((f) => {
    const sc = {
      luminosidad: r1(suave(f.n, f.l, glob.luminosidad)),
      posicion: r1(suave(f.n, f.p, glob.posicion)),
      seguridad: r1(suave(f.n, f.s, glob.seguridad)),
    };
    const total = r1(MEDIDAS.reduce((a, m) => a + pesos[m] * sc[m], 0));
    const c = { cupoId: f.id, cupo: f.codigo, piso: f.piso, tipo: f.tipo, opiniones: f.n, sinCalificar: f.n === 0, total, ...sc };
    // Con perfil, el orden usa el puntaje de la comunidad + un ajuste por afinidad (el "total" mostrado sigue siendo el de la comunidad)
    c.afinidad = perfil ? afinidadDe(perfil, c) : null;
    c.orden = total + (c.afinidad ? c.afinidad.bonus : 0);
    return c;
  }).sort((a, b) => b.orden - a.orden || b.total - a.total || b.opiniones - a.opiniones || a.cupo.localeCompare(b.cupo, undefined, { numeric: true }));

  return { candidatos, pesos, noche };
}

// Últimos comentarios visibles de un cupo (se envían a la IA como DATOS)
function comentariosDe(cupoId, limite = 3) {
  return db.prepare(`SELECT comentario FROM calificacion
    WHERE cupo_id = ? AND oculto = 0 AND comentario IS NOT NULL AND comentario <> ''
    ORDER BY id DESC LIMIT ?`).all(cupoId, limite).map((r) => r.comentario);
}

// Explicación de respaldo (sin IA)
function explicacionFormula(c) {
  if (c.opiniones === 0) return "Aún sin calificaciones: se sugiere según el orden del parqueadero. ¡Sé el primero en calificarlo!";
  const mejor = MEDIDAS.reduce((a, m) => (c[m] > c[a] ? m : a), MEDIDAS[0]);
  return `Destaca por su ${NOMBRE[mejor]} (${c[mejor]}/10), según ${c.opiniones} ${c.opiniones === 1 ? "opinión" : "opiniones"}.`;
}

module.exports = { MEDIDAS, PRIORIDADES, ranking, comentariosDe, explicacionFormula, esDeNoche };
