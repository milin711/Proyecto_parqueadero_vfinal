const fs = require("fs");
const path = require("path");
const db = require("./db");
const { BACKUP_DIR, BACKUP_KEEP } = require("./config");

const PREFIJO = "parqueadero-";

const archivos = () =>
  fs.existsSync(BACKUP_DIR)
    ? fs.readdirSync(BACKUP_DIR).filter((f) => f.startsWith(PREFIJO) && f.endsWith(".db")).sort()
    : [];

// Copia consistente de la base (segura aunque la app esté funcionando).
async function respaldar() {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
  const sello = new Date().toISOString().replace(/[:.]/g, "-");
  const destino = path.join(BACKUP_DIR, `${PREFIJO}${sello}.db`);
  await db.backup(destino);
  for (const viejo of archivos().slice(0, -BACKUP_KEEP)) fs.rmSync(path.join(BACKUP_DIR, viejo), { force: true });
  return destino;
}

// Hace un respaldo solo si el último tiene más de 24 horas (o no hay ninguno).
async function respaldarSiHaceFalta() {
  const ultimo = archivos().at(-1);
  if (ultimo && Date.now() - fs.statSync(path.join(BACKUP_DIR, ultimo)).mtimeMs < 24 * 3600e3) return;
  try { console.log("Respaldo creado:", await respaldar()); }
  catch (e) { console.error("No se pudo crear el respaldo:", e.message); }
}

// Borra los códigos de recuperación de contraseña ya vencidos.
const limpiarCodigos = () =>
  db.prepare("DELETE FROM recuperacion WHERE expira_en < ?").run(new Date().toISOString());

function iniciar() {
  limpiarCodigos();
  respaldarSiHaceFalta();
  setInterval(() => { limpiarCodigos(); respaldarSiHaceFalta(); }, 3600e3).unref(); // cada hora
}

module.exports = { iniciar, respaldar, limpiarCodigos };
