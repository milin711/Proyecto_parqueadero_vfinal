const express = require("express");
const cors = require("cors");
const path = require("path");
const { PORT, SECRET } = require("./config");
const { error } = require("./utils");
const db = require("./db"); // inicializa la base de datos (y aplica las migraciones pendientes)

const app = express();
app.use(cors());
app.use(express.json());

// Interfaz web (carpeta /public) -> se abre en http://localhost:3000
app.use(express.static(path.join(__dirname, "public")));

// Comprobación de salud (la usa Docker para saber si la app está viva)
app.get("/health", (req, res) => res.json({ ok: true }));

// Todos los endpoints viven en /routes
app.use("/api/v1", require("./routes"));

app.use((req, res) => error(res, 404, "Ruta no encontrada"));

if (process.env.NODE_ENV === "production" && SECRET === "cambia-esta-clave")
  console.warn("AVISO: usa un JWT_SECRET propio en el archivo .env (ahora se usa la clave por defecto).");

const server = app.listen(PORT, () => {
  console.log(`App lista en http://localhost:${PORT}`);
  console.log(`API en http://localhost:${PORT}/api/v1`);
  require("./mantenimiento").iniciar(); // limpieza de códigos vencidos + respaldo diario
});

// Al detener el contenedor (docker compose stop/down) se cierra la base limpiamente
const apagar = () => server.close(() => { try { db.close(); } catch {} process.exit(0); });
process.on("SIGTERM", apagar);
process.on("SIGINT", apagar);
