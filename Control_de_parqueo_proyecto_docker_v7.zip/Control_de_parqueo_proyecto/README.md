# ParkControl API

## Ejecutar

```bash
npm install
npm start
```

Corre en `http://localhost:3000/api/v1`. La primera vez crea `parqueadero.db` con
100 cupos (CR 01–CR 50 carros, MT 01–MT 35 motos, OT 01–OT 15 otros) y un usuario: **admin / admin123**.
En el primer ingreso el sistema **obliga a cambiar esa contraseña** (también se puede cambiar luego en *Admin → Cambiar mi contraseña*).

## Roles

| Rol | Cómo se obtiene | Qué puede hacer |
|---|---|---|
| `CLIENTE` (persona) | Se registra en la pantalla de inicio ("Soy usuario" → "Crea tu cuenta") | Registrar el ingreso de su vehículo, ver cupos libres, ver cuánto lleva dentro y cuánto pagaría ahora |
| `ADMIN` | Usuario `admin` (pestaña "Administrador") | Todo lo del operador + editar tarifas, datos del parqueadero y crear/editar/eliminar cupos |
| `OPERADOR` | Se inserta en la tabla `usuario` indicando `rol = 'OPERADOR'` (si no se indica rol, queda `CLIENTE`) | Registrar entradas y salidas, historial, poner cupos en mantenimiento |

Nuevos endpoints: `POST /auth/registro`, `GET /registros/mios`, `GET /tarifas`, `PUT /tarifas/:tipo` (ADMIN),
`PUT /parqueaderos/:id` (ADMIN), `POST|PUT|DELETE /cupos` (ADMIN), `PUT /auth/password` (cambiar mi contraseña).

## Probar con curl

```bash
# 1. Login (guarda el token)
curl -X POST localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"usuario":"admin","password":"admin123"}'

TOKEN="pega_aqui_el_token"

# 2. Resumen de ocupación
curl localhost:3000/api/v1/parqueaderos/1/resumen -H "Authorization: Bearer $TOKEN"

# 3. Cupos libres
curl "localhost:3000/api/v1/cupos?parqueaderoId=1&estado=LIBRE" -H "Authorization: Bearer $TOKEN"

# 4. Registrar entrada
curl -X POST localhost:3000/api/v1/registros/entrada \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"placa":"ABC123","tipoVehiculo":"CARRO","cupoId":1}'

# 5. Buscar registro activo
curl localhost:3000/api/v1/registros/activo/ABC123 -H "Authorization: Bearer $TOKEN"

# 6. Registrar salida
curl -X PATCH localhost:3000/api/v1/registros/1/salida \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"metodoPago":"EFECTIVO"}'

# 7. Historial
curl "localhost:3000/api/v1/registros?estado=FINALIZADO&page=1&size=10" -H "Authorization: Bearer $TOKEN"
```

## Recuperar contraseña por correo

1. Al registrarse, la persona escribe su **correo**. En el login, "¿Olvidaste tu contraseña?" pide ese correo y envía un código de 6 dígitos (vence en 15 min, sirve una sola vez, máx. 5 intentos y 1 solicitud por minuto).
2. Con el código la persona crea una contraseña nueva y vuelve a iniciar sesión.
3. El **admin** guarda su correo en *Admin → Mi correo de recuperación* (la cuenta `admin` viene sin correo).

**Enviar correos reales:** copia `.env.example` como `.env` y completa `SMTP_USER` y `SMTP_PASS`
(con Gmail usa una *contraseña de aplicación*: https://myaccount.google.com/apppasswords). Reinicia con `npm start`.
Sin `.env`, el servidor funciona en **modo pruebas**: en vez de enviar el correo, imprime el código en la consola.
Nunca subas tu `.env` a GitHub.

## Tarifas

**Cobro por minuto**: cada minuto cuenta y una fracción de minuto se cobra como minuto completo (mínimo 1 minuto). Tarifas iniciales: CARRO $150, MOTO $80, **OTRO (bicicleta) $10** por minuto.
**Tarifa plena**: desde las **3 horas** (180 minutos) se cobra un valor fijo por tipo de vehículo en lugar de contar minutos, y ya no sube por mucho que se quede. Valores iniciales = 180 × la tarifa por minuto (carro $27.000, moto $14.400, bicicleta $1.800), así el precio no da saltos al llegar a las 3 horas; el ADMIN los edita en *Admin → Tarifas por minuto y tarifa plena*. El tiempo (3 horas) se cambia con la variable `TARIFA_PLENA_MINUTOS`.
Se guardan en la base de datos y el ADMIN las edita desde la app (Admin → Tarifas).
`config.js` solo define los valores iniciales de una base nueva.

## Ejecutar con Docker

Requisito: Docker Desktop instalado y abierto (https://www.docker.com/products/docker-desktop/).

```bash
# 1) (Recomendado) crea tu archivo de configuración y complétalo
copy .env.example .env        # en Mac/Linux: cp .env.example .env

# 2) Construye y arranca (la primera vez tarda unos minutos y necesita internet)
docker compose up -d --build

# 3) Abre http://localhost:3000   (usuario admin / contraseña admin123)
```

| Para… | Comando |
|---|---|
| Ver si está corriendo (debe decir *healthy*) | `docker compose ps` |
| Ver los mensajes del servidor (y los códigos de recuperación en modo pruebas) | `docker compose logs -f` |
| Detener / volver a iniciar | `docker compose stop` / `docker compose start` |
| Apagar y quitar el contenedor (los datos se conservan) | `docker compose down` |
| Aplicar cambios hechos al código | `docker compose up -d --build` |

**Dónde quedan los datos:** la base de datos (`parqueadero.db`) vive en un **volumen de Docker** llamado `parkcontrol_datos`
(no en una carpeta de Windows: así SQLite es más rápido y seguro). Sobrevive a reinicios, a `docker compose down` y a actualizaciones.
**Ojo:** `docker compose down -v` sí borra el volumen y, con él, todos los datos.

**Variables (archivo `.env`):** `JWT_SECRET`, `SMTP_*` (correo), `HOST_PORT` (puerto del computador, por defecto 3000), `TZ` y `BACKUP_KEEP` (cuántos respaldos conservar, por defecto 14).
Si el puerto 3000 está ocupado, pon `HOST_PORT=3001` y abre http://localhost:3001.

## Base de datos (SQLite)

| Tabla | Contenido |
|---|---|
| `usuario` | Cuentas, contraseña cifrada y rol (`ADMIN`, `OPERADOR`, `CLIENTE`) |
| `parqueadero` | Nombre y dirección (la capacidad se calcula contando los cupos) |
| `cupo` | Espacios: tipo, piso y estado (`LIBRE`, `OCUPADO`, `MANTENIMIENTO`) |
| `registro` | Cada entrada/salida: placa, horas, **tarifa vigente al entrar**, valor y método de pago |
| `tarifa` | Precio por minuto de cada tipo de vehículo (`valor_minuto`) |
| `recuperacion` | Códigos temporales para recuperar contraseña (los vencidos se borran solos) |

Protecciones que aplica la propia base de datos:
- Una placa o un cupo **no pueden tener dos registros abiertos** a la vez.
- Solo se aceptan roles, tipos de cupo/vehículo y métodos de pago válidos (`EFECTIVO`, `TARJETA`, `TRANSFERENCIA`), y no hay valores negativos.
- Modo **WAL** y espera ante bloqueos: más rápida y resistente a cortes de luz o cierres bruscos.
- Índices en placa, estado, fecha, cupo y usuario para que el historial siga siendo rápido cuando crezca.
- Si el admin cambia una tarifa, **los vehículos que ya están dentro pagan la tarifa con la que entraron**.

**Migraciones:** la versión del esquema se guarda en la base (`PRAGMA user_version`). Al arrancar se aplican solas las que falten
(en `db.js`, lista `MIGRACIONES`). Antes de actualizar una base existente se crea una copia `parqueadero.db.antes-v2.bak` junto a ella.
Para cambiar el esquema en el futuro, agrega una migración nueva al final de esa lista; no edites las anteriores.

## Respaldos

- **Automáticos:** al arrancar y luego cada 24 h se guarda una copia en la carpeta **`respaldos/`** de tu proyecto
  (`parqueadero-FECHA.db`). Se conservan las últimas 14.
- **Uno manual ahora mismo:** `docker compose exec parkcontrol node respaldo.js`
- **Importante:** copia de vez en cuando la carpeta `respaldos/` a otro lugar (USB, nube). Si se daña el disco, se pierden la app y sus respaldos.

**Restaurar un respaldo** (reemplaza los datos actuales; cambia `NOMBRE.db` por el archivo que quieras):

```powershell
docker compose down
docker run --rm -v parkcontrol_datos:/data -v "${PWD}/respaldos:/respaldos" node:22-bookworm-slim sh -c "rm -f /data/parqueadero.db-wal /data/parqueadero.db-shm && cp /respaldos/NOMBRE.db /data/parqueadero.db && chown 1000:1000 /data/parqueadero.db"
docker compose up -d
```

**Llevar una base antigua** (por ejemplo la carpeta `data/` de la versión anterior) al volumen: pon el archivo en `respaldos/` y usa el mismo comando de restauración.
Al arrancar, la app lo actualiza sola al esquema nuevo.


## Sugerencias de cupo con IA y calificaciones

**Cómo funciona**
1. Al registrar su ingreso, la persona ve una barra con los 3 mejores cupos libres para su vehículo. Cada uno trae una puntuación de 0 a 10 en **luminosidad**, **posición** y **seguridad**, y la explicación de la IA. Por defecto se ordenan por **Mejor puntuado**; también puede dar prioridad a una medida (Luz, Posición, Seguridad).
2. Cuando el operador registra la **salida**, la persona ve esa salida en su pestaña **Historial** (solo existe para el rol usuario) y allí califica el cupo de 1 a 5 estrellas en luminosidad, posición y seguridad, con un comentario opcional. Solo puede calificar quien parqueó, una vez por salida, durante 14 días. Después queda en su historial con las estrellas que dio.
3. Esas calificaciones alimentan las sugerencias de los siguientes usuarios.

**Quién hace qué**
- El **sistema** calcula los puntajes (promedio de las calificaciones, suavizado para que un cupo con 1 sola opinión no gane a uno con 20; de noche la luminosidad pesa más).
- La **IA** elige la mejor opción entre los candidatos y la explica. No puede cambiar los puntajes ni elegir un cupo que no exista.
- Si no hay `IA_API_KEY`, la IA falla o se agota el tope por hora, la app **sigue funcionando** con la fórmula.

**Configurar la IA (Google AI Studio / Gemini):** crea una clave en https://aistudio.google.com/apikey, ponla en `IA_API_KEY` dentro del archivo `.env` (ver `.env.example`) y reinicia (`docker compose up -d`). Por defecto usa `gemini-3.5-flash-lite`; se puede cambiar con `IA_MODELO`. Para usar Claude en su lugar: `IA_PROVEEDOR=anthropic`. La clave solo vive en el servidor y **nunca debe compartirse**.
El panel **Admin → Calificaciones y usuarios** muestra si la IA está activa y con qué proveedor, y permite **ocultar** calificaciones indebidas.

**Privacidad:** a la IA solo se envían códigos de cupo, puntajes y comentarios anónimos; nunca placas ni nombres. Los comentarios se tratan como datos, no como instrucciones.

**Base de datos:** la migración v3 crea la tabla `calificacion`; al actualizar una base existente se hace antes una copia (`.antes-v3.bak`).
Endpoints: `GET /sugerencias`, `GET /registros/mios/historial` (solo usuario), `GET /calificaciones/pendientes`, `POST /calificaciones`, `GET /calificaciones/admin` y `PATCH /calificaciones/:id/oculto` (ADMIN).


## Sugerencias personalizadas

Si la persona ya tiene salidas registradas, en **Registrar ingreso** aparece el interruptor **"Personalizar con mi historial"** (activado por defecto). Con él:
- Los cupos donde ya parqueó y **calificó bien** (4★ o más) suben en el orden; los que calificó mal (2.5★ o menos) bajan.
- Usar un cupo 2 o más veces y estar en su zona habitual (piso donde parquea la mayoría de las veces) también suma un poco.
- Cada tarjeta muestra **por qué** ("Ya parqueaste aquí 2 veces", "Lo calificaste con 4★"…) y la IA puede mencionarlo en su explicación.
- El puntaje que se muestra (0 a 10) **sigue siendo el de la comunidad**; la personalización solo cambia el orden. Al apagar el interruptor vuelve el orden de la comunidad.
- Solo usa el historial del propio usuario. El personal (admin/operador) no recibe personalización.

## Asistente de preguntas (solo rol usuario)

Botón flotante **Asistente** en todas las pantallas del usuario. Responde sobre **su** parqueo: cuánto lleva y cuánto pagaría ahora, en una hora o a cierta hora, las tarifas, el costo de un tiempo para cada tipo de vehículo, sus salidas anteriores y cuántos cupos hay libres. Sus respuestas pueden traer botones para ir a la pantalla correspondiente.

**Cómo se evita que invente cosas**
- La IA **no escribe cifras**: usa marcadores (`{{costo_ahora:V1}}`, `{{tarifa:MOTO}}`…) que el servidor reemplaza con el valor exacto. Si escribe un número, un monto o "pesos" a mano, la respuesta se rechaza, se le corrige una vez y, si insiste, se contesta sin IA.
- El cobro usa la **misma tarifa congelada al entrar** que ve el usuario en *Mi vehículo*.
- A la IA no se le envían placas, nombres ni códigos de cupo; se usan alias (V1, S1…) y las placas que el usuario escriba se reemplazan antes de enviarlas.
- Sin clave, con fallo del proveedor o al llegar al tope por hora, responde en **modo básico** (datos exactos, sin redacción de IA) y lo indica.

**Cómo no se pisa con las sugerencias**
- El asistente **nunca recomienda cupos**: si se lo piden, explica y lleva a la barra de sugerencias. Los cupos los elige solo `sugerencias.js` + `perfil.js`.
- Topes y cachés separados: `IA_MAX_POR_HORA` (sugerencias) e `IA_CHAT_MAX_POR_HORA` (asistente, 20 por defecto).
- Endpoints: `POST /asistente` y `GET /asistente/estado` (solo rol CLIENTE); `GET /sugerencias?...&personalizar=1|0`.


## Cobro por minuto (migración v4)

Antes el cobro era por hora o fracción. Al actualizar una base existente, la migración v4 (con copia previa `.antes-v4.bak`):
- renombra `tarifa.valor_hora` → `valor_minuto` y `registro.tarifa_hora` → `tarifa_minuto`;
- deja las tarifas en las iniciales por minuto (carro 150, moto 80, otro 10): **las tarifas por hora anteriores no se pueden convertir**, así que si el admin las había personalizado debe volver a ajustarlas en *Admin → Tarifas*;
- los vehículos que están dentro en ese momento pasan a cobrarse por minuto con la tarifa nueva de su tipo;
- las salidas ya cobradas conservan su `valor_total`; su tarifa por hora se deja vacía porque ya no tiene equivalente.

El vehículo conserva la tarifa con la que entró aunque el admin cambie los precios después. API: `PUT /tarifas/:tipo` recibe `{ "valorMinuto": 150 }`; `GET /registros/mios` devuelve `tarifaMinuto`.


## Tarifa plena (migración v5)

Desde `TARIFA_PLENA_MINUTOS` (180 = 3 horas) se cobra la **tarifa plena** del tipo de vehículo, un valor fijo, en lugar de contar minutos: `valor = minutos >= 180 ? tarifaPlena : minutos x tarifaPorMinuto`.
- La migración v5 (con copia previa `.antes-v5.bak`) agrega `tarifa.valor_plena` y `registro.tarifa_plena`, inicia la plena en 180 × la tarifa por minuto vigente y la asigna a los vehículos que ya están dentro.
- Como la tarifa por minuto, **la plena se guarda al entrar**: si el admin la cambia, los vehículos que ya están dentro conservan la anterior.
- En *Admin* cada tipo muestra una referencia ("3 h por minuto = $27.000") para comparar. Si la plena queda por debajo de esa referencia, el precio baja al llegar a las 3 horas; si queda por encima, sube de golpe.
- API: `GET /tarifas/plena` → `{ desdeMinutos, valores }`; `PUT /tarifas/:tipo` acepta `{ valorMinuto?, valorPlena? }` (al menos uno). `GET /registros/mios` y `/registros/activo/:placa` devuelven `tarifaPlena`, `plenaAplicada`, `faltanParaPlenaMin` y `valorEstimado`.
- El asistente de preguntas la conoce (marcadores `{{tarifa_plena:TIPO}}`, `{{desde_plena}}`, `{{falta_plena:V1}}`) y sus cálculos de cobro la aplican igual que *Mi vehículo*.
