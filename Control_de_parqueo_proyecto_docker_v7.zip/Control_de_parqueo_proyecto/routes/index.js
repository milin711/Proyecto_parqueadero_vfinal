const express = require("express");
const auth = require("../middleware/auth");
const claveVigente = require("../middleware/claveVigente");

const router = express.Router();

// Públicas (login y registro de personas)
router.use("/auth", require("./auth.routes"));

// Protegidas (requieren Authorization: Bearer <token>). El rol se valida dentro de cada ruta.
// claveVigente bloquea la cuenta hasta que cambie la contraseña inicial.
router.use("/parqueaderos", auth, claveVigente, require("./parqueaderos.routes"));
router.use("/cupos", auth, claveVigente, require("./cupos.routes"));
router.use("/registros", auth, claveVigente, require("./registros.routes"));
router.use("/tarifas", auth, claveVigente, require("./tarifas.routes"));
router.use("/calificaciones", auth, claveVigente, require("./calificaciones.routes"));
router.use("/sugerencias", auth, claveVigente, require("./sugerencias.routes"));
router.use("/asistente", auth, claveVigente, require("./asistente.routes"));

module.exports = router;
