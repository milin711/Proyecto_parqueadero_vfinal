const express = require("express");
const roles = require("../middleware/roles");
const { error } = require("../utils");
const { IA } = require("../config");
const { iaActiva, limpio } = require("../ia");
const { preguntar } = require("../asistente");

const router = express.Router();

// Solo para personas (rol CLIENTE): el asistente habla de SU parqueo y nunca ve datos de otros.
router.use(roles("CLIENTE"));

// GET /api/v1/asistente/estado
router.get("/estado", (req, res) => res.json({ iaActiva: iaActiva(), proveedor: iaActiva() ? IA.nombre : null }));

// POST /api/v1/asistente  { mensaje, historial?: [{ rol: "usuario"|"asistente", texto }] }
//   -> { respuesta, acciones[], origen: "ia"|"respaldo", plantilla }
router.post("/", async (req, res) => {
  const mensaje = limpio(req.body?.mensaje, 1000);
  if (!mensaje) return error(res, 400, "Escribe tu pregunta");
  if (mensaje.length > 300) return error(res, 400, "La pregunta puede tener máximo 300 caracteres");
  res.json(await preguntar({ userId: req.user.id, mensaje, historial: req.body?.historial }));
});

module.exports = router;
