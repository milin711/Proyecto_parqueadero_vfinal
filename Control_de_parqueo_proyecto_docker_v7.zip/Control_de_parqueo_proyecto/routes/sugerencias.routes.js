const express = require("express");
const { error } = require("../utils");
const { TIPOS_VEHICULO, IA } = require("../config");
const { PRIORIDADES, ranking, comentariosDe, explicacionFormula, esDeNoche } = require("../sugerencias");
const { iaActiva, recomendar, limpio } = require("../ia");
const { perfilDe } = require("../perfil");

const router = express.Router();

// GET /api/v1/sugerencias?tipoVehiculo=MOTO&prioridad=mejor|luminosidad|posicion|seguridad&personalizar=1|0
// Devuelve hasta 3 cupos libres con su puntaje 0-10 por medida y la recomendación de la IA.
router.get("/", async (req, res) => {
  const tipoVehiculo = String(req.query.tipoVehiculo || "CARRO").toUpperCase();
  const pedida = req.query.prioridad === "equilibrado" ? "mejor" : req.query.prioridad; // "equilibrado" era el nombre anterior
  const prioridad = PRIORIDADES.includes(pedida) ? pedida : "mejor";
  if (!TIPOS_VEHICULO.includes(tipoVehiculo)) return error(res, 400, "tipoVehiculo inválido");

  // Personalización: solo para personas (rol CLIENTE) que ya tienen salidas; se puede apagar con personalizar=0
  const perfil = req.user.rol === "CLIENTE" ? perfilDe(req.user.id) : null;
  const personalizado = !!perfil && req.query.personalizar !== "0";
  const { candidatos, pesos, noche } = ranking({ tipoVehiculo, prioridad, perfil: personalizado ? perfil : null });
  const top = candidatos.slice(0, 5);
  let origen = "formula", resumen = "", mejor = top[0]?.cupo, explicaciones = {};

  // La IA solo interviene cuando hay algo que decidir (2 o más cupos) y hay clave configurada
  if (top.length >= 2 && iaActiva()) {
    try {
      const ia = await recomendar({
        vehiculo: tipoVehiculo.toLowerCase(), prioridad, personalizado, es_de_noche: noche, hora_del_dia: `${new Date().getHours()}:00`,
        candidatos: top.map((c) => ({
          cupo: c.cupo, piso: c.piso, total: c.total, luminosidad: c.luminosidad, posicion: c.posicion,
          seguridad: c.seguridad, opiniones: c.opiniones, comentarios: comentariosDe(c.cupoId).map((t) => limpio(t, 120)),
          ...(c.afinidad && { afinidad: { veces_que_parqueo: c.afinidad.veces, su_calificacion: c.afinidad.miCalificacion, es_su_zona_habitual: c.afinidad.zonaHabitual, lo_califico_bajo: c.afinidad.bonus <= -2 } }),
        })),
      }, req.user.id);
      if (ia) { origen = "ia"; mejor = ia.mejor; resumen = ia.resumen; explicaciones = ia.explicaciones; }
    } catch (e) {
      console.warn("IA no disponible, se usa la fórmula:", e.name === "AbortError" ? "tiempo agotado" : e.message);
    }
  }

  // La mejor opción según la IA va primero; el resto conserva el orden por puntaje
  const orden = [...top.filter((c) => c.cupo === mejor), ...top.filter((c) => c.cupo !== mejor)].slice(0, 3);
  res.json({
    tipoVehiculo, prioridad, origen, proveedor: origen === "ia" ? IA.nombre : null, modelo: origen === "ia" ? IA.modelo : null, noche, pesos, mejor: mejor ?? null,
    resumen, totalLibres: candidatos.length, personalizado, puedePersonalizar: !!perfil,
    sugerencias: orden.map((c, i) => ({
      cupoId: c.cupoId, cupo: c.cupo, piso: c.piso, total: c.total, luminosidad: c.luminosidad, posicion: c.posicion,
      seguridad: c.seguridad, opiniones: c.opiniones, sinCalificar: c.sinCalificar, esMejor: i === 0,
      afinidad: c.afinidad ? { razones: c.afinidad.razones, veces: c.afinidad.veces, miCalificacion: c.afinidad.miCalificacion } : null,
      explicacion: explicaciones[c.cupo] || (c.afinidad?.razones[0] ? `${c.afinidad.razones[0]}. ` : "") + explicacionFormula(c),
    })),
  });
});

module.exports = router;
