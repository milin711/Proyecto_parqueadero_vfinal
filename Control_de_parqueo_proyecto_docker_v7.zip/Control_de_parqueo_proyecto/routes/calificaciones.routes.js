const express = require("express");
const db = require("../db");
const roles = require("../middleware/roles");
const { error } = require("../utils");
const { iaActiva, limpio } = require("../ia");
const { IA, DIAS_PARA_CALIFICAR } = require("../config");

const router = express.Router();
const desde = () => new Date(Date.now() - DIAS_PARA_CALIFICAR * 864e5).toISOString();

// GET /api/v1/calificaciones/pendientes  ->  mis salidas recientes que aún no he calificado
router.get("/pendientes", (req, res) => {
  const filas = db.prepare(`
    SELECT r.id, r.placa, r.tipo_vehiculo, r.hora_salida, c.codigo
    FROM registro r JOIN cupo c ON c.id = r.cupo_id
    WHERE r.usuario_id = ? AND r.estado = 'FINALIZADO' AND r.hora_salida >= ?
      AND NOT EXISTS (SELECT 1 FROM calificacion k WHERE k.registro_id = r.id)
    ORDER BY r.hora_salida DESC LIMIT 5`).all(req.user.id, desde());
  res.json(filas.map((r) => ({ registroId: r.id, placa: r.placa, cupo: r.codigo, tipoVehiculo: r.tipo_vehiculo, horaSalida: r.hora_salida })));
});

// POST /api/v1/calificaciones  { registroId, luminosidad, posicion, seguridad, comentario? }
// Solo puede calificar quien parqueó (dueño del registro), cuando la salida ya está registrada, una vez por salida.
router.post("/", (req, res) => {
  const b = req.body || {};
  const registroId = Number(b.registroId);
  const notas = ["luminosidad", "posicion", "seguridad"].map((k) => Number(b[k]));
  if (!Number.isInteger(registroId) || registroId < 1) return error(res, 400, "registroId es obligatorio");
  if (notas.some((n) => !Number.isInteger(n) || n < 1 || n > 5)) return error(res, 400, "Cada medida se califica de 1 a 5 estrellas");
  const comentario = limpio(b.comentario, 1000);
  if (comentario.length > 200) return error(res, 400, "El comentario puede tener máximo 200 caracteres");

  const r = db.prepare("SELECT * FROM registro WHERE id = ?").get(registroId);
  if (!r || r.usuario_id !== req.user.id) return error(res, 404, "No encontramos esa salida entre tus registros");
  if (r.estado !== "FINALIZADO") return error(res, 409, "Podrás calificar cuando se registre tu salida");
  if (r.hora_salida < desde()) return error(res, 409, `Ya pasaron más de ${DIAS_PARA_CALIFICAR} días para calificar esta salida`);

  try {
    db.prepare(`INSERT INTO calificacion (registro_id, cupo_id, usuario_id, luminosidad, posicion, seguridad, comentario, creado_en)
                VALUES (?,?,?,?,?,?,?,?)`).run(r.id, r.cupo_id, req.user.id, ...notas, comentario || null, new Date().toISOString());
  } catch (e) {
    if (String(e.code).startsWith("SQLITE_CONSTRAINT")) return error(res, 409, "Ya calificaste esta salida");
    throw e;
  }
  res.status(201).json({ mensaje: "¡Gracias! Tu calificación ayuda a otros conductores." });
});

// ---------- Moderación (solo ADMIN) ----------

// GET /api/v1/calificaciones/admin  ->  estado de la IA y últimas calificaciones
router.get("/admin", roles("ADMIN"), (req, res) => {
  const t = db.prepare("SELECT COUNT(*) n, AVG(luminosidad) l, AVG(posicion) p, AVG(seguridad) s FROM calificacion WHERE oculto = 0").get();
  const recientes = db.prepare(`
    SELECT k.id, k.luminosidad, k.posicion, k.seguridad, k.comentario, k.oculto, k.creado_en, c.codigo, u.nombre
    FROM calificacion k JOIN cupo c ON c.id = k.cupo_id JOIN usuario u ON u.id = k.usuario_id
    ORDER BY k.id DESC LIMIT 30`).all();
  const r1 = (x) => (x == null ? null : Math.round(x * 20) / 10); // estrellas (1-5) -> 0-10
  res.json({
    iaActiva: iaActiva(), proveedor: iaActiva() ? IA.nombre : null, modelo: iaActiva() ? IA.modelo : null, total: t.n,
    promedios: { luminosidad: r1(t.l), posicion: r1(t.p), seguridad: r1(t.s) },
    recientes: recientes.map((k) => ({
      id: k.id, cupo: k.codigo, usuario: k.nombre, luminosidad: k.luminosidad, posicion: k.posicion, seguridad: k.seguridad,
      comentario: k.comentario, oculto: !!k.oculto, creadoEn: k.creado_en,
    })),
  });
});

// PATCH /api/v1/calificaciones/:id/oculto  { oculto: true|false }  ->  una calificación oculta no cuenta para las sugerencias
router.patch("/:id/oculto", roles("ADMIN"), (req, res) => {
  if (typeof req.body?.oculto !== "boolean") return error(res, 400, "oculto debe ser true o false");
  const r = db.prepare("UPDATE calificacion SET oculto = ? WHERE id = ?").run(req.body.oculto ? 1 : 0, req.params.id);
  if (!r.changes) return error(res, 404, "Calificación no existe");
  res.json({ id: Number(req.params.id), oculto: req.body.oculto });
});

module.exports = router;
