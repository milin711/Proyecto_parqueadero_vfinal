const express = require("express");
const db = require("../db");
const roles = require("../middleware/roles");
const { error, getTarifas, getPlenas, PLENA_DESDE_MIN } = require("../utils");

const router = express.Router();

// GET /api/v1/tarifas  ->  todos los roles   { CARRO: 150, ... }  (pesos por minuto)
router.get("/", (req, res) => res.json(getTarifas()));

// GET /api/v1/tarifas/plena  ->  todos los roles   { desdeMinutos, valores: { CARRO: 27000, ... } }
router.get("/plena", (req, res) => res.json({ desdeMinutos: PLENA_DESDE_MIN, valores: getPlenas() }));

// PUT /api/v1/tarifas/:tipo  ->  solo ADMIN   body: { valorMinuto?, valorPlena? }  (al menos uno)
router.put("/:tipo", roles("ADMIN"), (req, res) => {
  const tipo = String(req.params.tipo).toUpperCase();
  if (!Object.hasOwn(getTarifas(), tipo)) return error(res, 404, "Tipo de vehículo no existe");
  const { valorMinuto, valorPlena } = req.body || {};
  if (valorMinuto === undefined && valorPlena === undefined) return error(res, 400, "Envía valorMinuto y/o valorPlena");

  if (valorMinuto !== undefined) {
    const v = Number(valorMinuto);
    if (!Number.isInteger(v) || v < 0 || v > 100000) return error(res, 400, "valorMinuto debe ser un número entero entre 0 y 100.000 (pesos por minuto)");
  }
  if (valorPlena !== undefined) {
    const v = Number(valorPlena);
    if (!Number.isInteger(v) || v < 1 || v > 10000000) return error(res, 400, "valorPlena debe ser un número entero entre 1 y 10.000.000 (pesos)");
  }
  db.transaction(() => {
    if (valorMinuto !== undefined) db.prepare("UPDATE tarifa SET valor_minuto = ? WHERE tipo = ?").run(Number(valorMinuto), tipo);
    if (valorPlena !== undefined) db.prepare("UPDATE tarifa SET valor_plena = ? WHERE tipo = ?").run(Number(valorPlena), tipo);
  })();
  res.json({ tipo, valorMinuto: getTarifas()[tipo], valorPlena: getPlenas()[tipo] });
});

module.exports = router;
